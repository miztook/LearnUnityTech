CREATE SCHEMA `account` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin ;
USE `account`;
-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: 10.24.0.24    Database: account
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `access_token_version`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_token_version` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID，无业务用途',
  `iggid` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'IGGID',
  `hashed_udid` varchar(20) NOT NULL DEFAULT '' COMMENT '哈希后的设备标识',
  `min_version` int unsigned NOT NULL DEFAULT '0' COMMENT '最低版本号',
  `updated_at` int unsigned NOT NULL DEFAULT '0' COMMENT '最后更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `iggid` (`iggid`,`hashed_udid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account` (
  `igg_id` varchar(255) NOT NULL,
  `last_login_rid` bigint DEFAULT '0',
  `list` text,
  `ban` tinyint DEFAULT '0',
  PRIMARY KEY (`igg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pay_record`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pay_record` (
  `order_id` bigint NOT NULL,
  `rid` bigint DEFAULT NULL,
  `sn` varchar(100) DEFAULT NULL,
  `pay_id` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `create_time` int DEFAULT NULL,
  `complete_time` int DEFAULT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `server_config`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `server_config` (
  `server_id` int NOT NULL,
  `redirect_switch` int DEFAULT '0',
  `register_switch` int DEFAULT '0',
  `data` varchar(250) DEFAULT NULL,
  `status` int DEFAULT '0' COMMENT '服务器状态，1：开，0：关',
  `openTime` int DEFAULT '0' COMMENT '开服时间',
  `gate_id` int DEFAULT NULL,
  `alliance_id` int DEFAULT NULL,
  PRIMARY KEY (`server_id`),
  KEY `choose` (`status`,`redirect_switch`,`register_switch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sp_add_game_login_log_v6`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sp_add_game_login_log_v6` (
  `logid` int unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID，日志id',
  `gameid` varchar(20) NOT NULL COMMENT '游戏版本ID，我们会给每个游戏版本分配一个ID',
  `serverid` varchar(20) NOT NULL COMMENT '游戏服务器ID（王国ID）',
  `iggid` varchar(255) NOT NULL DEFAULT '' COMMENT 'IGGID',
  `ip` varchar(45) NOT NULL DEFAULT '' COMMENT '用户登录的外网ip',
  `time` bigint NOT NULL COMMENT '用户登录时间戳',
  `session_id` varchar(32) NOT NULL DEFAULT '' COMMENT '登录session',
  `auth_status` smallint NOT NULL DEFAULT '0' COMMENT '实名认证状态(0无需认证;1认证通过;2需认证的游客用户;3认证中)',
  `udid` varchar(128) NOT NULL DEFAULT '' COMMENT '设备标识',
  `pi` varchar(50) NOT NULL DEFAULT '' COMMENT '实名认证用户标识',
  `client_version` varchar(20) NOT NULL DEFAULT '' COMMENT '客户端版本号',
  PRIMARY KEY (`logid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sp_add_game_logout_log_v6`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sp_add_game_logout_log_v6` (
  `logid` int unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID，日志id',
  `gameid` varchar(20) NOT NULL COMMENT '游戏版本ID，我们会给每个游戏版本分配一个ID',
  `serverid` varchar(20) NOT NULL COMMENT '游戏服务器ID（王国ID）',
  `iggid` varchar(255) NOT NULL DEFAULT '' COMMENT 'IGGID',
  `ip` varchar(45) NOT NULL DEFAULT '' COMMENT '用户登出的外网ip',
  `time` bigint NOT NULL COMMENT '用户登出时间戳',
  `online_seconds` int NOT NULL COMMENT '用户本次游戏在线时长(秒)，登出时间减去登录时间的秒数，无法计算的话就填0',
  `session_id` varchar(32) NOT NULL DEFAULT '' COMMENT '登录session',
  `auth_status` smallint NOT NULL DEFAULT '0' COMMENT '实名认证状态(0无需认证;1认证通过;2需认证的游客用户;3认证中)',
  `udid` varchar(128) NOT NULL DEFAULT '' COMMENT '设备标识',
  `pi` varchar(50) NOT NULL DEFAULT '' COMMENT '实名认证用户标识',
  `client_version` varchar(20) NOT NULL DEFAULT '' COMMENT '客户端版本号',
  PRIMARY KEY (`logid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-28 10:49:28
